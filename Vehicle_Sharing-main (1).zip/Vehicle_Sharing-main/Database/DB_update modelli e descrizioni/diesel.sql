
UPDATE `veicoli` SET `modello`= 'Fiat 500L ', `descrizione`= 'Spaziosa e funzionale, è dedicata a chi cerca tanto spazio e grazie al motori a gasolio della famiglia Multijet si dimostra anche molto parca nei consumi. La Fiat 500L garantisce una ottima abitabilità interna grazie alla sua lunghezza di quattro metri e ventiquattro centimetri. Le proporzioni della vettura sono equilibrate grazie anche ad una larghezza pari a 178 centimetri e ad una altezza di un metro e sessantasei. Buona la capacità del bagagliaio che, con il divanetto posteriore in posizione, è di 412 litri.' WHERE `modello`= 'Fiat 500X';

UPDATE `veicoli` SET `modello`= 'Fiat 500L ', `descrizione`= 'Spaziosa e funzionale, è dedicata a chi cerca tanto spazio e grazie al motori a gasolio della famiglia Multijet si dimostra anche molto parca nei consumi. La Fiat 500L garantisce una ottima abitabilità interna grazie alla sua lunghezza di quattro metri e ventiquattro centimetri. Le proporzioni della vettura sono equilibrate grazie anche ad una larghezza pari a 178 centimetri e ad una altezza di un metro e sessantasei. Buona la capacità del bagagliaio che, con il divanetto posteriore in posizione, è di 412 litri.' WHERE `alimentazione`= 'Diesel';







