package com.generation.fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MioFileUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
