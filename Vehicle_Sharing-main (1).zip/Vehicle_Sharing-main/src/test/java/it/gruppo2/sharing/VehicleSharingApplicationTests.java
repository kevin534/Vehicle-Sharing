package it.gruppo2.sharing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleSharingApplicationTests {

	@Test
	void contextLoads() {
	}

}
